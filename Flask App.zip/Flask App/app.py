import flask
import os
import json
import requests 
import sys
from flask_cors import CORS

app = flask.Flask(__name__)
CORS(app)

# Get port from environment variable or choose 9099 as local default
port = int(os.getenv("PORT", 9099))

@app.route('/weather', methods=['GET'])
def predict():
    city = flask.request.args.get('city') ## Input
	##display = flask.request.args.get('text') ## Input
    base_url = "http://api.openweathermap.org/data/2.5/weather?q="+city+"&appid="
    api_key = "cbf40c31dc6e53a5b63069b956572b3a"
    url = base_url+api_key
    response = requests.get(url)
    result = response.json()
    temperature = result['main']['temp']
    #print('Works', file=sys.stderr)
    temperature_degree = temperature - 273.15
    return flask.jsonify(temperature_degree)
	
if __name__ == '__main__':
    # Run the app, listening on all IPs with our chosen port number
    app.run(host='0.0.0.0', port=port)
